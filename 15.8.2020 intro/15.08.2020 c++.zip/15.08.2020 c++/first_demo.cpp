#include<iostream>
using namespace std;

int main()
{
    cout<<"Hello World 1"<<endl;
    cout<<"Hello World 2"<<endl;
    return 0;
}
