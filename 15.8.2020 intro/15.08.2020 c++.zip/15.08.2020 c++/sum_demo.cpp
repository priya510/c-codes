//WAP in c++ to accept two numbers from user and print sum.

#include<iostream>
using namespace std;

int main()
{
    int a,b;

    cout<<"Enter two numbers"<<endl;
    cin>>a>>b;

    cout<<"Sum : "<<a+b;
    return 0;
}
