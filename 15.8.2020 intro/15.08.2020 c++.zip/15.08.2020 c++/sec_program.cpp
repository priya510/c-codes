#include<iostream>
using namespace std;

int main()
{
    cout<<"myself Priya \n";
    cout<<"course name is C++ \n";
    return 0;
}

