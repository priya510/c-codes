#include<iostream>
using namespace std;

int main()
{
    char arr[]={"India"};
    cout<<arr;
}
