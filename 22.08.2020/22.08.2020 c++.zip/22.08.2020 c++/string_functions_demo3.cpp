#include<iostream>
#include<string.h>
using namespace std;

int main()
{
    char arr2[]={};

    strncpy(arr2,"Hello",3);

    cout<<arr2<<endl;
    return 0;
}

